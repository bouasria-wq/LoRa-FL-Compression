#!/usr/bin/env python3
"""
TEST 02 — Packet Reliability
===============================
Compares single-packet ME-CFL (242 bytes, 1 LoRa packet)
against multi-packet baseline (2212 bytes, 9 LoRa fragments).

Key insight:
  If ANY fragment is lost, the ENTIRE model update fails.
  P(success for 1 packet)  = (1 - PER)^1
  P(success for 9 packets) = (1 - PER)^9

  At 5% packet error rate:
    1 packet:  95% success
    9 packets: 0.95^9 = 63% success

Metrics:
  - PDR vs Packet Error Rate (PER) sweep
  - Success probability comparison at key PER values
  - Expected rounds to deliver one successful update

Presentation:
  - Line graph: PDR vs PER for both methods
  - Bar chart: success rate at PER=5%
  - Table: summary statistics

Usage:
  cd ~/LoRa_Fl_Compression.proj
  python3 test02/run_test02.py

File: test02/run_test02.py
"""

import numpy as np
import os
from pathlib import Path

# ─── LoRa parameters ─────────────────────────────────────────────
LORA_MAX_PAYLOAD = 255   # bytes per LoRa packet
COMPRESSED_SIZE  = 242   # ME-CFL Hegazy compressed
RAW_SIZE         = 2212  # uncompressed float32 × 553 params

SF = 7
BW = 125000
CR = 2
PREAMBLE_LEN = 8


def packets_needed(total_bytes):
    return int(np.ceil(total_bytes / LORA_MAX_PAYLOAD))


def calculate_toa(payload_bytes):
    n_preamble = PREAMBLE_LEN
    numerator = 8 * payload_bytes - 4 * SF + 28 + 16
    denominator = 4 * (SF - 2)
    payload_symbols = max(np.ceil(numerator / denominator) * (CR + 4), 0)
    n_symbols = n_preamble + payload_symbols
    return (n_symbols * (2 ** SF)) / BW


def round_success_prob(n_packets, per):
    """Probability ALL packets in a round succeed."""
    return (1 - per) ** n_packets


def expected_rounds_to_success(n_packets, per):
    """Expected number of attempts to get one successful round."""
    p = round_success_prob(n_packets, per)
    if p <= 0:
        return float('inf')
    return 1.0 / p


def monte_carlo_pdr(n_packets, per, n_rounds=10000, rng=None):
    """
    Simulate n_rounds of transmission. Each round sends n_packets.
    If ALL packets succeed, the round succeeds.
    Returns measured PDR.
    """
    if rng is None:
        rng = np.random.default_rng(42)

    successes = 0
    for _ in range(n_rounds):
        # Each packet has independent probability of failure
        packet_results = rng.random(n_packets) > per
        if packet_results.all():  # ALL must succeed
            successes += 1

    return successes / n_rounds


def run_per_sweep():
    """Sweep PER from 0% to 30% and compute PDR for both methods."""
    n_compressed = packets_needed(COMPRESSED_SIZE)  # 1 packet
    n_raw = packets_needed(RAW_SIZE)                # 9 packets

    per_values = np.arange(0, 0.31, 0.01)
    results = []

    print(f"\nPacket counts: Compressed={n_compressed}, Raw={n_raw}")
    print(f"\n{'PER':>6} | {'Compressed PDR':>15} | {'Raw PDR':>15} | "
          f"{'Compressed Rounds':>18} | {'Raw Rounds':>12}")
    print("-" * 75)

    for per in per_values:
        # Analytical
        pdr_comp = round_success_prob(n_compressed, per) * 100
        pdr_raw  = round_success_prob(n_raw, per) * 100

        # Monte Carlo validation
        mc_comp = monte_carlo_pdr(n_compressed, per) * 100
        mc_raw  = monte_carlo_pdr(n_raw, per) * 100

        rounds_comp = expected_rounds_to_success(n_compressed, per)
        rounds_raw  = expected_rounds_to_success(n_raw, per)

        results.append({
            'per': per * 100,
            'pdr_compressed': pdr_comp,
            'pdr_raw': pdr_raw,
            'mc_compressed': mc_comp,
            'mc_raw': mc_raw,
            'rounds_compressed': rounds_comp,
            'rounds_raw': rounds_raw,
        })

        if per * 100 % 5 == 0:
            print(f"{per*100:5.0f}% | {pdr_comp:14.1f}% | {pdr_raw:14.1f}% | "
                  f"{rounds_comp:17.2f} | {rounds_raw:11.2f}")

    return results


def run_simulation_with_fl(per=0.05, n_rounds=7, n_homes=10):
    """
    Simulate FL rounds with packet loss.
    Shows how many homes successfully deliver per round.
    """
    rng = np.random.default_rng(42)
    n_comp = packets_needed(COMPRESSED_SIZE)
    n_raw  = packets_needed(RAW_SIZE)

    print(f"\n{'='*60}")
    print(f"FL SIMULATION WITH {per*100:.0f}% PACKET ERROR RATE")
    print(f"{'='*60}")
    print(f"  {n_homes} homes × {n_rounds} rounds")
    print(f"  Compressed: {n_comp} packet/home | Raw: {n_raw} packets/home")

    comp_deliveries = []
    raw_deliveries  = []

    for r in range(1, n_rounds + 1):
        comp_ok = 0
        raw_ok  = 0
        for h in range(n_homes):
            # Compressed: 1 packet
            if rng.random(n_comp).all() > per if n_comp == 1 else (rng.random(n_comp) > per).all():
                comp_ok += 1
            # Raw: 9 packets — ALL must succeed
            if (rng.random(n_raw) > per).all():
                raw_ok += 1

        comp_deliveries.append(comp_ok)
        raw_deliveries.append(raw_ok)

        print(f"  Round {r}: Compressed {comp_ok}/{n_homes} delivered | "
              f"Raw {raw_ok}/{n_homes} delivered")

    comp_total = sum(comp_deliveries)
    raw_total  = sum(raw_deliveries)
    comp_pdr = comp_total / (n_homes * n_rounds) * 100
    raw_pdr  = raw_total / (n_homes * n_rounds) * 100

    print(f"\n  Total deliveries: Compressed {comp_total}/{n_homes*n_rounds} "
          f"({comp_pdr:.1f}%) | Raw {raw_total}/{n_homes*n_rounds} ({raw_pdr:.1f}%)")

    return comp_deliveries, raw_deliveries


def generate_plots(sweep_results, comp_deliveries, raw_deliveries, output_dir):
    """Generate IEEE-quality plots."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    plt.rcParams.update({
        'font.size': 12,
        'font.family': 'serif',
        'figure.figsize': (8, 5),
        'axes.grid': True,
        'grid.alpha': 0.3,
        'lines.linewidth': 2.5,
        'lines.markersize': 8,
        'axes.spines.top': False,
        'axes.spines.right': False,
    })

    os.makedirs(output_dir, exist_ok=True)

    # ─── Plot 1: PDR vs PER sweep ────────────────────────────────
    fig, ax = plt.subplots(figsize=(8, 5))

    pers = [r['per'] for r in sweep_results]
    pdr_comp = [r['pdr_compressed'] for r in sweep_results]
    pdr_raw  = [r['pdr_raw'] for r in sweep_results]

    ax.plot(pers, pdr_comp, 'o-', color='#1a5276', markersize=4,
            label=f'ME-CFL (1 packet, {COMPRESSED_SIZE}B)')
    ax.plot(pers, pdr_raw, 's--', color='#e67e22', markersize=4,
            label=f'Baseline (9 packets, {RAW_SIZE}B)')

    # Highlight PER=5%
    ax.axvline(x=5, color='gray', linestyle=':', alpha=0.7)
    ax.annotate('PER = 5%', xy=(5, 50), fontsize=10, color='gray',
                ha='left', va='bottom')

    # Annotate key values at PER=5%
    idx_5 = 5  # index for PER=5%
    ax.annotate(f'{pdr_comp[idx_5]:.0f}%',
                xy=(5, pdr_comp[idx_5]), xytext=(8, pdr_comp[idx_5] + 2),
                fontsize=11, fontweight='bold', color='#1a5276',
                arrowprops=dict(arrowstyle='->', color='#1a5276'))
    ax.annotate(f'{pdr_raw[idx_5]:.0f}%',
                xy=(5, pdr_raw[idx_5]), xytext=(8, pdr_raw[idx_5] - 5),
                fontsize=11, fontweight='bold', color='#e67e22',
                arrowprops=dict(arrowstyle='->', color='#e67e22'))

    ax.set_xlabel('Packet Error Rate (%)')
    ax.set_ylabel('Round Success Rate (%)')
    ax.set_title('Packet Reliability: Single-Packet vs Multi-Packet')
    ax.legend(loc='lower left', fontsize=10)
    ax.set_xlim([0, 30])
    ax.set_ylim([0, 105])

    plt.tight_layout()
    plt.savefig(f'{output_dir}/fig1_pdr_vs_per.pdf', dpi=300, bbox_inches='tight')
    plt.savefig(f'{output_dir}/fig1_pdr_vs_per.png', dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Saved: fig1_pdr_vs_per.pdf")

    # ─── Plot 2: Bar chart at key PER values ─────────────────────
    fig, ax = plt.subplots(figsize=(8, 5))

    key_pers = [1, 3, 5, 10, 15, 20]
    comp_vals = []
    raw_vals  = []
    for p in key_pers:
        r = sweep_results[p]
        comp_vals.append(r['pdr_compressed'])
        raw_vals.append(r['pdr_raw'])

    x = np.arange(len(key_pers))
    width = 0.35

    bars1 = ax.bar(x - width/2, comp_vals, width, label='ME-CFL (1 packet)',
                   color='#1a5276', edgecolor='white', linewidth=1.5)
    bars2 = ax.bar(x + width/2, raw_vals, width, label='Baseline (9 packets)',
                   color='#e67e22', edgecolor='white', linewidth=1.5)

    # Add value labels
    for bar in bars1:
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                f'{bar.get_height():.0f}%', ha='center', fontsize=9,
                fontweight='bold', color='#1a5276')
    for bar in bars2:
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                f'{bar.get_height():.0f}%', ha='center', fontsize=9,
                fontweight='bold', color='#e67e22')

    ax.set_xlabel('Packet Error Rate (%)')
    ax.set_ylabel('Round Success Rate (%)')
    ax.set_title('Success Rate Comparison at Different Error Rates')
    ax.set_xticks(x)
    ax.set_xticklabels([f'{p}%' for p in key_pers])
    ax.legend(loc='upper right', fontsize=10)
    ax.set_ylim([0, 115])

    plt.tight_layout()
    plt.savefig(f'{output_dir}/fig2_bar_per_comparison.pdf', dpi=300, bbox_inches='tight')
    plt.savefig(f'{output_dir}/fig2_bar_per_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Saved: fig2_bar_per_comparison.pdf")

    # ─── Plot 3: FL round delivery simulation ────────────────────
    fig, ax = plt.subplots(figsize=(8, 5))

    rounds = list(range(1, len(comp_deliveries) + 1))
    n_homes = 10

    ax.bar(np.array(rounds) - 0.2, comp_deliveries, 0.35,
           label='ME-CFL (1 pkt/home)', color='#1a5276',
           edgecolor='white', linewidth=1.5)
    ax.bar(np.array(rounds) + 0.2, raw_deliveries, 0.35,
           label='Baseline (9 pkts/home)', color='#e67e22',
           edgecolor='white', linewidth=1.5)

    ax.axhline(y=n_homes, color='gray', linestyle=':', alpha=0.7,
               label=f'All {n_homes} homes')

    ax.set_xlabel('FL Communication Round')
    ax.set_ylabel('Homes Successfully Delivered')
    ax.set_title(f'Model Delivery per Round (PER = 5%, {n_homes} homes)')
    ax.legend(loc='lower right', fontsize=10)
    ax.set_xticks(rounds)
    ax.set_ylim([0, n_homes + 1])

    plt.tight_layout()
    plt.savefig(f'{output_dir}/fig3_fl_delivery_per_round.pdf', dpi=300, bbox_inches='tight')
    plt.savefig(f'{output_dir}/fig3_fl_delivery_per_round.png', dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Saved: fig3_fl_delivery_per_round.pdf")

    # ─── Plot 4: Expected retransmissions ─────────────────────────
    fig, ax = plt.subplots(figsize=(8, 5))

    pers_plot = [r['per'] for r in sweep_results if r['per'] <= 25]
    rounds_comp = [r['rounds_compressed'] for r in sweep_results if r['per'] <= 25]
    rounds_raw  = [r['rounds_raw'] for r in sweep_results if r['per'] <= 25]

    ax.plot(pers_plot, rounds_comp, 'o-', color='#1a5276', markersize=4,
            label='ME-CFL (1 packet)')
    ax.plot(pers_plot, rounds_raw, 's--', color='#e67e22', markersize=4,
            label='Baseline (9 packets)')

    ax.set_xlabel('Packet Error Rate (%)')
    ax.set_ylabel('Expected Attempts per Successful Delivery')
    ax.set_title('Retransmission Cost')
    ax.legend(loc='upper left', fontsize=10)

    plt.tight_layout()
    plt.savefig(f'{output_dir}/fig4_retransmissions.pdf', dpi=300, bbox_inches='tight')
    plt.savefig(f'{output_dir}/fig4_retransmissions.png', dpi=300, bbox_inches='tight')
    plt.close()
    print(f"  Saved: fig4_retransmissions.pdf")


def print_summary(sweep_results):
    """Print summary table."""
    n_comp = packets_needed(COMPRESSED_SIZE)
    n_raw  = packets_needed(RAW_SIZE)

    print(f"\n{'='*70}")
    print(f"TEST 02 RESULTS — PACKET RELIABILITY")
    print(f"{'='*70}")

    print(f"\n{'Metric':<35} {'ME-CFL':<20} {'Baseline':<20}")
    print(f"{'-'*70}")
    print(f"{'Payload size':<35} {COMPRESSED_SIZE:<20} {RAW_SIZE:<20}")
    print(f"{'Packets per home':<35} {n_comp:<20} {n_raw:<20}")

    toa_comp = calculate_toa(COMPRESSED_SIZE)
    toa_raw  = n_raw * calculate_toa(LORA_MAX_PAYLOAD)
    print(f"{'Total ToA per home':<35} {toa_comp:<20.4f}s {toa_raw:<20.4f}s")

    for per_pct in [1, 3, 5, 10, 15, 20]:
        r = sweep_results[per_pct]
        print(f"\n  At PER = {per_pct}%:")
        print(f"    {'Round success rate':<31} {r['pdr_compressed']:<20.1f}% {r['pdr_raw']:<19.1f}%")
        print(f"    {'Expected attempts':<31} {r['rounds_compressed']:<20.2f} {r['rounds_raw']:<19.2f}")

    # Headline number
    r5 = sweep_results[5]
    print(f"\n{'HEADLINE (PER=5%)':<35}")
    print(f"{'-'*70}")
    print(f"{'ME-CFL success rate':<35} {r5['pdr_compressed']:.1f}%")
    print(f"{'Baseline success rate':<35} {r5['pdr_raw']:.1f}%")
    print(f"{'Advantage':<35} {r5['pdr_compressed'] - r5['pdr_raw']:.1f} percentage points")
    print(f"{'Baseline failure risk':<35} "
          f"{100 - r5['pdr_raw']:.1f}% (vs {100 - r5['pdr_compressed']:.1f}%)")


def main():
    print("=" * 60)
    print("TEST 02 — PACKET RELIABILITY")
    print("Single-packet (242B) vs Multi-packet (2212B, 9 fragments)")
    print("=" * 60)

    output_dir = str(Path(__file__).parent / 'results')

    # PER sweep
    print("\n--- PER Sweep (Analytical + Monte Carlo) ---")
    sweep_results = run_per_sweep()

    # FL simulation with 5% PER
    comp_del, raw_del = run_simulation_with_fl(per=0.05, n_rounds=7, n_homes=10)

    # Summary
    print_summary(sweep_results)

    # Plots
    print(f"\nGenerating IEEE-quality plots...")
    generate_plots(sweep_results, comp_del, raw_del, output_dir)

    print(f"\nAll results saved to: {output_dir}/")
    print("Done!")


if __name__ == "__main__":
    main()
