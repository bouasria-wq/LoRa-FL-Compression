import numpy as np
from gnuradio import gr

class chirp_ratio_drop_modulator(gr.sync_block):
    """
    Drop samples inside each chirp based on a list of ratio patterns.
    For example: drop_pattern = [0.1, 0.5, 0.4] means:
      drop first 10% of chirp 0,
      drop first 50% of chirp 1,
      drop first 40% of chirp 2,
      then repeat...
    """

    def __init__(self, sf=7, bw=125000, fs=500000, preamble_chirps=12.25, drop_pattern=None):
        gr.sync_block.__init__(
            self,
            name="chirp_ratio_drop_modulator",
            in_sig=[np.complex64],
            out_sig=[np.complex64],
        )

        self.sf = sf
        self.bw = bw
        self.fs = fs
        self.Tc = 2 ** sf / bw
        self.samples_per_symbol = int(self.Tc * fs)
        self.N = self.samples_per_symbol
        self.preamble_samples = int(preamble_chirps * self.N)

        self.sample_index = 0
        self.chirp_index = 0

        self.drop_pattern = drop_pattern or [0.1, 0.5, 0.4]
        self.pattern_idx = 0

    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]
        total_samples = len(in0)
        out[:] = 0
        N = self.N

        i = 0

        # preamble 透传
        if self.sample_index < self.preamble_samples:
            pre_end = min(self.preamble_samples - self.sample_index, total_samples)
            out[:pre_end] = in0[:pre_end]
            self.sample_index += pre_end
            return pre_end

        # payload 开始处理
        i = max(i, self.preamble_samples - self.sample_index)

        while i + N <= total_samples:
            chirp = in0[i:i + N].copy()  # 保证不在原始内存上操作

            ratio = self.drop_pattern[self.pattern_idx]
            drop_samples = int(ratio * N)

            chirp[:drop_samples] = 0  # 丢弃前面的部分
            out[i:i + N] = chirp

            print(f"[{self.sample_index}] chirp {self.chirp_index} - DROP {drop_samples} samples ({ratio*100:.1f}%)")

            self.chirp_index += 1
            self.sample_index += N
            i += N

            self.pattern_idx = (self.pattern_idx + 1) % len(self.drop_pattern)

        return i
