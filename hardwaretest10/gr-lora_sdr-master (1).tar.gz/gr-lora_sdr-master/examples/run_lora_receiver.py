#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import signal
import sys
import time

from lora_RX import lora_RX as LoraRX


def main():
    rx_tb = None
    stopped = False

    def stop_rx():
        nonlocal stopped
        if stopped:
            return
        stopped = True

        if rx_tb is not None:
            try:
                rx_tb.stop()
            except Exception as exc:
                print(f"[WARN] RX stop failed: {exc}")

            try:
                rx_tb.wait()
            except Exception as exc:
                print(f"[WARN] RX wait failed: {exc}")

    def sig_handler(sig=None, frame=None):
        stop_rx()
        sys.exit(0)

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    try:
        rx_tb = LoraRX()
        rx_tb.start()
        print("LoRa Receiver is running. Press Enter to quit.")

        try:
            input()
        except EOFError:
            while True:
                time.sleep(1)
    finally:
        stop_rx()


if __name__ == "__main__":
    main()
