import numpy as np
from gnuradio import gr

class chirp_mask_modulator(gr.sync_block):
    """
    Chirp Mask Modulator:
    Repeats input LoRa chirps, keeping or absorbing them based on a binary pattern.
    """

    def __init__(self, sf=7, bw=125000, fs=500000, preamble_chirps=12.25, pattern=None):
        gr.sync_block.__init__(
            self,
            name="chirp_mask_modulator",
            in_sig=[np.complex64],
            out_sig=[np.complex64],
        )

        # 参数设置
        self.sf = sf
        self.bw = bw
        self.fs = fs
        self.Tc = 2 ** sf / bw
        self.samples_per_symbol = int(self.Tc * fs)
        self.N = self.samples_per_symbol
        self.preamble_samples = int(preamble_chirps * self.N)

        self.sample_index = 0
        self.pattern = pattern or [1, 0, 1, 0]  # 默认重复使用
        self.pattern_index = 0

    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]

        total_samples = len(in0)
        out[:] = 0  # 默认输出为 0
        N = self.N

        i = 0

        # 透传 preamble
        if self.sample_index < self.preamble_samples:
            pre_end = min(self.preamble_samples - self.sample_index, total_samples)
            out[:pre_end] = in0[:pre_end]
            self.sample_index += pre_end
            return pre_end

        # 跳到 payload 起始位置
        i = max(i, self.preamble_samples - self.sample_index)

        # 按 chirp 分段处理
        while i + N <= total_samples:
            chirp = in0[i:i + N]
            mask_flag = self.pattern[self.pattern_index % len(self.pattern)]

            if mask_flag == 1:
                out[i:i + N] = chirp
            else:
                out[i:i + N] = np.zeros_like(chirp)  # 吸收该 chirp

            print(f"[{self.sample_index}] Pattern[{self.pattern_index}] = {mask_flag}")

            self.pattern_index += 1
            self.sample_index += N
            i += N

        return i
