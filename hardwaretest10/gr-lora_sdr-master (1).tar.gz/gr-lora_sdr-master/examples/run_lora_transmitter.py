#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import signal
import sys
import time

try:
    import pmt
except ImportError:
    from gnuradio import pmt

from lora_TX import lora_TX as LoraTX

INPUT_PAR_VALUES = [
    37.6991, 39.1920,
    37.7885, 39.2897,
    37.8778, 39.3274,
    37.9668, 39.2848,
    38.0551, 39.1614,
    38.1425, 38.9568,
    38.2288, 38.6712,
    38.3138, 38.3061,
    38.3978, 37.8630,
    38.4810, 37.3434,
    38.5638, 36.7488,
    38.6465, 36.0810,
    38.7296, 35.3418,
    38.8134, 34.5332,
    38.8982, 33.6557,
    38.9843, 32.7081,
    39.0717, 31.6900,
    39.1600, 30.6024,
    39.2492, 29.4466,
    39.3389, 28.2238,
    39.4291, 26.9358,
    39.5195, 25.5839,
    39.6098, 24.1700,
    39.7001, 22.6960,
    39.7899, 21.1637,
]

TX_INTERVAL_S = 0.000001


def send_input_par_sequence(tx_tb, values, interval_s):
    msg_port = pmt.intern("msg")
    whitening_block = tx_tb.lora_sdr_whitening_0.to_basic_block()

    for idx, value in enumerate(values, start=1):
        payload = f"{value:.4f}"
        whitening_block._post(msg_port, pmt.intern(payload))
        print(f"[TX] sent {idx:02d}/{len(values)} input_par={payload}")
        time.sleep(interval_s)


def main():
    tx_tb = None
    stopped = False

    def stop_tx():
        nonlocal stopped
        if stopped:
            return
        stopped = True

        if tx_tb is not None:
            try:
                tx_tb.stop()
            except Exception as exc:
                print(f"[WARN] TX stop failed: {exc}")

            try:
                tx_tb.wait()
            except Exception as exc:
                print(f"[WARN] TX wait failed: {exc}")

    def sig_handler(sig=None, frame=None):
        stop_tx()
        sys.exit(0)

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    try:
        tx_tb = LoraTX()

        # Disable default periodic strobe payload from lora_TX.py.
        tx_tb.set_frame_period(10_000_000)

        tx_tb.start()

        print(
            f"LoRa Transmitter started. Sending {len(INPUT_PAR_VALUES)} packets "
            f"(interval={TX_INTERVAL_S}s)..."
        )
        send_input_par_sequence(tx_tb, INPUT_PAR_VALUES, TX_INTERVAL_S)
        print("Float sequence send completed.")

        # Keep a short tail for last frame flush.
        time.sleep(1.0)
    finally:
        stop_tx()


if __name__ == "__main__":
    main()
